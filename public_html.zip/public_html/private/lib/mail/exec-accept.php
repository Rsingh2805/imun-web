<?php

require_once dirname(__FILE__) . '/mail.php';

applicationAcceptedMail($argv[1], $argv[2], $argv[3]);