<?php

require_once dirname(__FILE__) . '/mail.php';

paymentPendingMail($argv[1], $argv[2]);