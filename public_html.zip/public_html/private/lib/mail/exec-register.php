<?php

require_once dirname(__FILE__) . '/mail.php';

registeredSuccessfullyMail($argv[1], $argv[2]);