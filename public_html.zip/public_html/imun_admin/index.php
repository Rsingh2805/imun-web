<?php
header("Location:dashbord.php");

?>